# Bee Totem - Minecraft 26.3

Client-only Fabric mod for Minecraft 26.3.

## Behavior

- First person: the Totem of Undying is replaced by the uploaded bee model.
- First person: the bee is static.
- F5 third person front: the bee sits on your right shoulder and faces the camera.
- F5 third person back: the bee stays aligned with you and shows its back.
- Third person held Totem: the item in your hand remains the normal Totem.
- Other players: they see your normal Totem; the custom shoulder bee is rendered only for the local player.
- The uploaded BBModel Idle animation is used for the shoulder bee.

## Shoulder position

The main tuning constants are in:

src/main/java/dev/beetotem/client/render/BeeShoulderRenderLayer.java

Change:
- RIGHT_SIDE to false for the left shoulder.
- SCALE to change bee size.
- X, Y, Z to fine-tune the shoulder position.

## Dependencies

Minecraft 26.3
Fabric Loader 0.19.5
Fabric API 0.161.0+26.3
Java 25
Loom 1.17.x

BactroMod is optional and is not declared as a hard dependency.

## Build

Open this project in a Fabric/Loom-compatible Java 25 development environment and run the normal Gradle build task.
