package dev.beetotem;

import dev.beetotem.client.model.BeeTotemModel;
import dev.beetotem.client.render.BeeShoulderRenderLayer;
import dev.beetotem.client.render.BeeTotemSpecialRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityRenderLayerRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.entity.state.PlayerRenderState;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.resources.Identifier;
import net.minecraft.client.renderer.special.SpecialModelRenderers;

public final class BeeTotemClient implements ClientModInitializer {
    public static final String MOD_ID = "bee_totem";

    @Override
    public void onInitializeClient() {
        ModelLayerRegistry.registerModelLayer(BeeTotemModel.LAYER, BeeTotemModel::createBodyLayer);

        SpecialModelRenderers.ID_MAPPER.put(
                Identifier.of(MOD_ID, "bee"),
                BeeTotemSpecialRenderer.Unbaked.MAP_CODEC
        );

        LivingEntityRenderLayerRegistrationCallback.EVENT.register(
                (entityType, entityRenderer, registrationHelper, context) -> {
                    if (entityType == EntityType.PLAYER && entityRenderer instanceof PlayerRenderer playerRenderer) {
                        registrationHelper.register(
                                new BeeShoulderRenderLayer(
                                        playerRenderer,
                                        context.getEntityModels()
                                )
                        );
                    }
                }
        );
    }
}
