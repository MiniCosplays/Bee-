package dev.beetotem.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.beetotem.client.model.BeeTotemModel;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.special.SpecialModelRenderer;
import net.minecraft.client.resources.model.sprite.AtlasIds;
import net.minecraft.client.resources.model.sprite.SpriteGetter;
import net.minecraft.client.resources.model.sprite.SpriteId;
import net.minecraft.core.component.DataComponentMap;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Unit;
import net.minecraft.world.item.ItemStack;
import org.joml.Vector3fc;

import java.util.function.Consumer;

public final class BeeTotemSpecialRenderer implements SpecialModelRenderer<DataComponentMap> {
    private final SpriteGetter sprites;
    private final BeeTotemModel model;
    private final SpriteId spriteId;
    private final boolean animated;

    public BeeTotemSpecialRenderer(
            SpriteGetter sprites,
            BeeTotemModel model,
            SpriteId spriteId,
            boolean animated
    ) {
        this.sprites = sprites;
        this.model = model;
        this.spriteId = spriteId;
        this.animated = animated;
    }

    @Override
    public DataComponentMap extractArgument(ItemStack stack) {
        return stack.immutableComponents();
    }

    @Override
    public void submit(
            DataComponentMap components,
            PoseStack poseStack,
            SubmitNodeCollector collector,
            int lightCoords,
            int overlayCoords,
            boolean hasFoil,
            int outlineColor
    ) {
        poseStack.pushPose();
        BeeTotemModel.applyItemTransform(poseStack);

        // First-person uses the same bee model but stays completely static.
        // Third-person uses the uploaded BBModel Idle animation.
        float time = System.nanoTime() / 1_000_000_000.0f;
        model.applyPose(time, animated);

        collector.submitModel(
                model,
                Unit.INSTANCE,
                poseStack,
                lightCoords,
                overlayCoords,
                -1,
                spriteId,
                sprites,
                outlineColor,
                null
        );

        poseStack.popPose();
    }

    @Override
    public void getExtents(Consumer<Vector3fc> output) {
        PoseStack poseStack = new PoseStack();
        model.root().getExtentsForGui(poseStack, output);
    }

    public record Unbaked(Identifier texture, boolean animate)
            implements SpecialModelRenderer.Unbaked<DataComponentMap> {

        public static final MapCodec<Unbaked> MAP_CODEC = RecordCodecBuilder.mapCodec(instance ->
                instance.group(
                        Identifier.CODEC.fieldOf("texture").forGetter(Unbaked::texture),
                        com.mojang.serialization.Codec.BOOL.fieldOf("animate").forGetter(Unbaked::animate)
                ).apply(instance, Unbaked::new)
        );

        @Override
        public MapCodec<Unbaked> type() {
            return MAP_CODEC;
        }

        @Override
        public BeeTotemSpecialRenderer bake(SpecialModelRenderer.BakingContext context) {
            return new BeeTotemSpecialRenderer(
                    context.sprites(),
                    new BeeTotemModel(
                            context.entityModelSet().bakeLayer(BeeTotemModel.LAYER)
                    ),
                    new SpriteId(AtlasIds.ITEMS, texture),
                    animate
            );
        }
    }
}
