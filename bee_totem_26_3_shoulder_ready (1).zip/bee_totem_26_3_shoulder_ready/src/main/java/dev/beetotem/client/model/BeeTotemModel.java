package dev.beetotem.client.model;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.model.CubeListBuilder;
import net.minecraft.client.model.LayerDefinition;
import net.minecraft.client.model.MeshDefinition;
import net.minecraft.client.model.Model;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.PartDefinition;
import net.minecraft.client.model.PartPose;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.util.Unit;

public final class BeeTotemModel extends Model<Unit> {
    public static final net.minecraft.client.model.geom.ModelLayerLocation LAYER =
            new net.minecraft.client.model.geom.ModelLayerLocation(
                    Identifier.of("bee_totem", "bee"),
                    "main"
            );

    private static final float SCALE = 0.08f;
    private static final float MODEL_YAW = (float) Math.toRadians(-90.0f);

    private final ModelPart root;
    private final ModelPart bodyPart;
    private final ModelPart wing1;
    private final ModelPart wing2;

    public BeeTotemModel(ModelPart root) {
        super(RenderTypes::entityCutoutNoCull);
        this.root = root;
        this.bodyPart = root.getChild("bodyPart");
        this.wing1 = bodyPart.getChild("wing1");
        this.wing2 = bodyPart.getChild("wing2");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition bodyPart = root.addOrReplaceChild(
                "bodyPart",
                CubeListBuilder.create(),
                PartPose.ZERO
        );

        bodyPart.addOrReplaceChild(
                "body",
                CubeListBuilder.create()
                        .texOffs(0, 0)
                        .addBox(-1.0f, -3.02618f, -1.99966f, 7.0f, 5.0f, 5.0f),
                PartPose.ZERO
        );

        float legT = 0.08f;
        bodyPart.addOrReplaceChild(
                "leg1",
                CubeListBuilder.create().texOffs(16, 0)
                        .addBox(0.75f - legT / 2.0f, 0.47382f, -1.0f, legT, 3.0f, 1.0f),
                PartPose.ZERO
        );
        bodyPart.addOrReplaceChild(
                "leg2",
                CubeListBuilder.create().texOffs(16, 0)
                        .addBox(0.75f - legT / 2.0f, 0.47382f, 1.0f, legT, 3.0f, 1.0f),
                PartPose.ZERO
        );
        bodyPart.addOrReplaceChild(
                "leg3",
                CubeListBuilder.create().texOffs(16, 0)
                        .addBox(3.75f - legT / 2.0f, 0.47382f, 1.0f, legT, 3.0f, 1.0f),
                PartPose.ZERO
        );
        bodyPart.addOrReplaceChild(
                "leg4",
                CubeListBuilder.create().texOffs(16, 0)
                        .addBox(3.75f - legT / 2.0f, 0.47382f, -1.0f, legT, 3.0f, 1.0f),
                PartPose.ZERO
        );

        bodyPart.addOrReplaceChild(
                "wing1",
                CubeListBuilder.create().texOffs(32, 0)
                        .addBox(1.0f, -2.0f, -2.0f, 3.0f, 0.08f, 4.0f),
                PartPose.offsetAndRotation(
                        0.0f, -3.02618f, -0.99966f,
                        (float) Math.toRadians(45.0f), 0.0f, 0.0f
                )
        );
        bodyPart.addOrReplaceChild(
                "wing2",
                CubeListBuilder.create().texOffs(32, 0)
                        .addBox(2.0f, -2.0f, 2.0f, 3.0f, 0.08f, 4.0f),
                PartPose.offsetAndRotation(
                        0.0f, -3.02618f, 2.00034f,
                        (float) Math.toRadians(-135.0f), 0.0f,
                        (float) Math.toRadians(-180.0f)
                )
        );

        return LayerDefinition.create(mesh, 48, 16);
    }

    private static float sample(float time, float length, float[][] data, int component) {
        if (data.length == 0) return 0.0f;

        float t = time % length;
        if (t < 0.0f) t += length;

        if (t <= data[0][0]) return data[0][component];

        for (int i = 1; i < data.length; i++) {
            if (t <= data[i][0]) {
                float t0 = data[i - 1][0];
                float t1 = data[i][0];
                float local = (t - t0) / (t1 - t0);
                return Mth.lerp(local, data[i - 1][component], data[i][component]);
            }
        }

        int last = data.length - 1;
        float wrapDuration = length - data[last][0] + data[0][0];
        float local = wrapDuration <= 0.0f ? 0.0f : (t - data[last][0]) / wrapDuration;
        return Mth.lerp(local, data[last][component], data[0][component]);
    }

    // Values below are the uploaded BBModel's Idle animation keyframes.
    private static final float[][] BODY_ROT = {
        {0.0f, 0.0f}, {0.14815f, -2.5f}, {0.22222f, 2.5f},
        {0.29630f, 1.5f}, {0.37037f, 12.5f}, {0.44444f, 0.5f},
        {0.51852f, -11.5f}, {0.59259f, 0.5f}
    };

    private static final float[][] BODY_POS_Y = {
        {0.0f, 0.0f}, {0.07407f, -0.25f}, {0.14815f, -0.3f},
        {0.22222f, 0.4f}, {0.29630f, 0.8f}, {0.37037f, 0.8f},
        {0.44444f, 1.6f}, {0.51852f, -0.4f}, {0.59259f, -1.4f},
        {0.66667f, 0.0f}
    };

    private static final float[][] BODY_POS_Z = {
        {0.0f, 0.0f}, {0.07407f, 0.0f}, {0.14815f, 1.1f},
        {0.22222f, 1.5f}, {0.29630f, 0.4f}, {0.37037f, -0.4f},
        {0.44444f, -2.9f}, {0.51852f, -2.8f}, {0.59259f, -2.2f},
        {0.66667f, 0.0f}
    };

    private static final float[][] WING1_ROT = {
        {0.0f, 0.0f}, {0.07407f, 57.5f}, {0.14815f, 0.0f},
        {0.22222f, 57.5f}, {0.29630f, 0.0f}, {0.37037f, 57.5f},
        {0.44444f, 0.0f}, {0.51852f, 57.5f}, {0.59259f, 0.0f},
        {0.66667f, 57.5f}
    };

    private static final float[][] WING2_ROT = {
        {0.0f, -2.5f}, {0.07407f, -59.5f}, {0.14815f, -2.5f},
        {0.22222f, -59.5f}, {0.29630f, -2.5f}, {0.37037f, -59.5f},
        {0.44444f, -2.5f}, {0.51852f, -59.5f}, {0.59259f, -2.5f},
        {0.66667f, -59.5f}
    };

    public void applyPose(float timeSeconds, boolean animated) {
        root.resetPose();
        if (!animated) return;

        final float length = 0.66667f;

        bodyPart.xRot = (float) Math.toRadians(sample(timeSeconds, length, BODY_ROT, 1));
        bodyPart.yRot = 0.0f;
        bodyPart.zRot = 0.0f;

        // The BBModel Body part has X position keyframes all at zero,
        // so no X translation is needed.
        bodyPart.x = 0.0f;
        bodyPart.y = sample(timeSeconds, length, BODY_POS_Y, 1);
        bodyPart.z = sample(timeSeconds, length, BODY_POS_Z, 1);

        wing1.xRot += (float) Math.toRadians(sample(timeSeconds, length, WING1_ROT, 1));
        wing2.xRot += (float) Math.toRadians(sample(timeSeconds, length, WING2_ROT, 1));
    }

    public static void applyItemTransform(PoseStack poseStack) {
        poseStack.scale(SCALE, SCALE, SCALE);
        poseStack.translate(-2.5f, 0.75f, -0.5f);
        poseStack.mulPose(Axis.YP.rotation(MODEL_YAW));
    }
}
