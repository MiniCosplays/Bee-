package dev.beetotem.client.render;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.beetotem.BeeTotemClient;
import dev.beetotem.client.model.BeeTotemModel;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.Model;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.entity.state.PlayerRenderState;
import net.minecraft.client.renderer.entity.model.LoadedEntityModels;
import net.minecraft.client.resources.model.sprite.AtlasIds;
import net.minecraft.client.resources.model.sprite.SpriteGetter;
import net.minecraft.client.resources.model.sprite.SpriteId;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.util.Unit;
import org.joml.Vector3fc;

import java.util.function.Consumer;

public final class BeeShoulderRenderLayer extends RenderLayer<PlayerRenderState, PlayerModel<PlayerRenderState>> {
    private static final Identifier TEXTURE =
            Identifier.of(BeeTotemClient.MOD_ID, "item/bee");

    /*
     * Shoulder settings:
     * RIGHT_SIDE = true puts the bee on the player's right shoulder.
     * Change to false for the left shoulder.
     */
    private static final boolean RIGHT_SIDE = true;
    private static final float SCALE = 1.15f;
    private static final float X = 0.38f;
    private static final float Y = 1.35f;
    private static final float Z = 0.02f;

    private final BeeTotemModel model;
    private final SpriteGetter sprites;
    private final SpriteId spriteId;

    public BeeShoulderRenderLayer(
            RenderLayerParent<PlayerRenderState, PlayerModel<PlayerRenderState>> parent,
            LoadedEntityModels entityModels
    ) {
        super(parent);
        this.model = new BeeTotemModel(entityModels.bakeLayer(BeeTotemModel.LAYER));
        this.sprites = Minecraft.getInstance().getAtlasManager().getAtlas(AtlasIds.ITEMS);
        this.spriteId = new SpriteId(AtlasIds.ITEMS, TEXTURE);
    }

    @Override
    public void render(
            PoseStack poseStack,
            SubmitNodeCollector collector,
            int light,
            PlayerRenderState state,
            float limbAngle,
            float limbDistance
    ) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null || state.id != minecraft.player.getId() || state.spectator) return;

        ItemStack mainHand = minecraft.player.getMainHandItem();
        ItemStack offHand = minecraft.player.getOffhandItem();
        if (!isTotem(mainHand) && !isTotem(offHand)) return;

        poseStack.pushPose();

        // Player renderer space is already in entity-model coordinates.
        // This keeps the bee aligned with the player's yaw:
        // F5 front -> bee faces the camera; F5 back -> bee shows its back.
        poseStack.translate(RIGHT_SIDE ? X : -X, Y, Z);
        poseStack.scale(SCALE, SCALE, SCALE);

        float time = System.nanoTime() / 1_000_000_000.0f;
        model.applyPose(time, true);

        collector.submitModel(
                model,
                Unit.INSTANCE,
                poseStack,
                light,
                0,
                -1,
                spriteId,
                sprites,
                0,
                null
        );

        poseStack.popPose();
    }

    private static boolean isTotem(ItemStack stack) {
        return stack.is(Items.TOTEM_OF_UNDYING);
    }

    @Override
    public void getExtents(Consumer<Vector3fc> output) {
        PoseStack poseStack = new PoseStack();
        model.root().getExtentsForGui(poseStack, output);
    }
}
